<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Líneas de Idioma de Paginación
    |--------------------------------------------------------------------------
    |
    | Las siguientes líneas de idioma son utilizadas por la biblioteca del paginador
    | para construir los enlaces de paginación simples. Eres libre de cambiarlos
    | a lo que desees para personalizar tus vistas y que coincidan mejor con tu aplicación.
    |
    */

    'previous' => '&laquo; Anterior',
    'next' => 'Siguiente &raquo;',

];
