<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\MoodleServiceProvider::class,
    RealRashid\SweetAlert\SweetAlertServiceProvider::class,
];
